#!/bin/bash

# 1. Prompt the user for the name of the directory to create
read -p "Enter the name of the folder to create for the xyz files (e.g., ammonium): " target_dir

# Exit if the user just presses Enter without typing a name
if [ -z "$target_dir" ]; then
    echo "Error: Directory name cannot be empty. Please run the script again."
    exit 1
fi

# 2. Create the target directory
mkdir -p "$target_dir"
echo "Created target directory: $target_dir/"
echo "------------------------------------------------"

# 3. Loop through ALL directories in the current path
for dir in */; do
    # Get the clean folder name by removing the trailing slash
    folder_name=$(basename "$dir")
    
    # Skip the target directory itself so we don't look inside the folder we just made
    if [ "$folder_name" == "$target_dir" ]; then
        continue
    fi
    
    # Define the path to the coordinates file
    coord_file="${dir}optimized_coordinates.txt"
    
    # 4. Check if the coordinates file actually exists in this subfolder
    if [ -f "$coord_file" ]; then
        # Count the number of rows (atoms) in the txt file
        num_atoms=$(wc -l < "$coord_file")
        
        # Define the output .xyz file path
        out_file="${target_dir}/${folder_name}.xyz"
        
        # Create the .xyz file with the required format
        echo "$num_atoms" > "$out_file"       # Line 1: Number of atoms
        echo "" >> "$out_file"                # Line 2: Blank comment line
        cat "$coord_file" >> "$out_file"      # Line 3+: The coordinate data
        
        echo "Successfully converted: $folder_name -> $out_file"
    fi
done

echo "------------------------------------------------"
echo "All done! Your .xyz files are safely saved in the '$target_dir' folder."



